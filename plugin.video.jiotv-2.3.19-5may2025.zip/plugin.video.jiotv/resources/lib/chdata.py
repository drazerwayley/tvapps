
dai = "https://dai.google.com/ssai/event/%s/master.m3u8"

zfpg = "plugin://plugin.video.zee5/?action=playNew&vid=0-9-%s&sid=%s&itemtype=LIVE"

intUrls = {
        153: ("9z5383489", "Movie"), # Zee Talkies SD
        154: "UI4QFJ_uRk6aLxIcADqa_A", #SBSD
        155: "DD7fA-HgSUaLyZp9AjRYxQ", #T5HD
        162: "yeYP86THQ4yl7US8Zx5eug", #T1HD
        165: ("zeecinemahd", "Movie"),
        167: ("zeetvhd", "Entertainment"),
        185: ("tvpictureshd", "Movie"), # &pictures HD
        289: "oJ-TGgVFSgSMBUoTkauvFQ", #MXSD
        291: "HgaB-u6rSpGx3mo4Xu3sLw", #STHD
        413: ("9z5383488", "Movie"), # Zee Cinemalu SD
        414: ("zeeyuva", "Entertainment"),
        415: ("zeeanmolcinema", "Movie"),
        445: ("9z5383486", "Entertainment"), # Zee Marathi SD
        471: "UI4QFJ_uRk6aLxIcADqa_A", #SBHD
        472: ("tvhd_0", "Entertainment"), # &tv HD,
        473: ("zeeanmol", "Entertainment"),
        474: "rPzF28qORbKZkhci_04fdQ", #PL
        476: "Qyqz40bSQriqSuAC7R8_Fw", #MXHD
        483: "4Jcu195QTpCNBXGnpw2I6g", #MX2
        484: ("zeecinema", "Movie"),
        487: ("zeeclassic", "Movie"),
        488: ("zeeaction", "Movie"),
        514: "4_pnLi2QTe6bRGvvahRbfg", #T1
        523: "nspQRqO5RmC06VmlPrTwkQ", #T2
        524: "9kocjiLUSf-erlSrv3d4Mw", #T3
        525: "S-q8I27RRzmkb-OIdoaiAw", #T5
        585: ("zing", "Music"),
        625: ("9z5383484", "Entertainment"), # Zee Bangla SD
        628: ("9z5383487", "Entertainment"), # Zee Tamil SD
        638: ("9z5383485", "Entertainment"), # Zee Telugu SD
        685: ("zeebanglacinema", "Movie"),
        689: ("9z5383466", "Entertainment"), # Zee Kannada
        697: "pSVzGmMpQR6jdmwwJg87OQ", #Ath
        722: ("sarthaktv", "Entertainment"),
        762: "8FR5Q-WfRWCkbMq_GxZ77w", #PXHD
        821: "V73ovbgASP-xGvQQOukwTQ", #BEHD
        823: "V73ovbgASP-xGvQQOukwTQ", #BEHD
        872: "40H5HfwWTZadFGYkBTqagg", #YYHn
        873: "40H5HfwWTZadFGYkBTqagg", #YYTm
        874: "40H5HfwWTZadFGYkBTqagg", #YYTl
        891: "Syu8F41-R1y_JmQ7x0oNxQ", #T2HD
        892: "nmQFuHURTYGQBNdUG-2Qdw",#T3HHn
        1146: "-_w3Jbq3QoW-mFCM2YIzxA", #MrSD
        1319: ("zeecafehd", "Entertainment"),
        1322: ("channel_2105335046", "Movie"), # &flix HD
        1349: ("9z5543514", "Movie"), # &prive HD
        1351: ("zeetv", "Entertainment"), #SD
        1354: ("zeetelugu", "Entertainment"), #HD
        1356: ("zeetamil", "Entertainment"), # HD
        1358: ("zeetalkies", "Movie"), #HD
        1359: ("bigmagic_1786965389", "Entertainment"),
        1360: ("zeemarathi", "Entertainment"), #HD
        1362: ("zeekannada", "Entertainment"), # HD
        1363: ("zeecinemalu", "Movie"), # Zee Cinemalu HD
        1393: "H_ZvXWqHRGKpHcdDE5RcDA", #WH
        1396: "HgaB-u6rSpGx3mo4Xu3sLw", #STSD
        1530: "8FR5Q-WfRWCkbMq_GxZ77w", #PXSD
        1641: ("129", "Entertainment"), # Zee Keralam HD
        1668: ("209", "Movie"), # &xplor HD
        1751: ("215", "Entertainment"), # Zee Punjabi
        1772: "x4LxWUcVSIiDaq1VCM7DSA", #T4HDTm
        1773: "x4LxWUcVSIiDaq1VCM7DSA", #T4HDTl
        1774: "hInaEKUJSziZAGv9boOdjg", #TN4Tm
        1775: "hInaEKUJSziZAGv9boOdjg", #TN4Tl
        1977: ("zeebangla", "Entertainment"), #HD
        2256: ("224", "Movie"), # Zee Thirai
        2757: ("348", "Lifestyle"), # Zee Zest HD
        2758: ("394", "Movie"), # Zee Chitramandir
        2761: ("bigganga", "Movie"), # Zee Anmol Cinema 2
        2861: "nmQFuHURTYGQBNdUG-2Qdw", #T3HMr
        3047: ("241", "Movie"), # Zee Picchar SD
    }
